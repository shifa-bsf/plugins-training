<?php
/**
 *  Plugin Name: Are You Paying Attention Quiz
 *  Description: Giving readers a multiple choice question.
 *  Version: 1.0
 *   Author: Shifa
 *
 * @package {{package}}
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Class Are_You_Paying_Attention.
 */
class  Are_You_Paying_Attention {
	/**
	 * Constructor
	 */
	function __construct() {
		add_action( 'init', array( $this, 'aypa_admin_assets' ) );
	}

	/**
	 * Register block type
	 */
	function aypa_admin_assets() {
		register_block_type(
			__DIR__,
			array(
				'render_callback' => array( $this, 'aypa_the_html' ),
			)
		);
	}

	/**
	 * Function for render callback
	 */
	function aypa_the_html( $attributes ) {
		if ( ! is_admin() ) {
			wp_enqueue_script( 'attentionFrontend', plugin_dir_url( __FILE__ ) . 'build/frontend.js', array( 'wp-element' ) );
		}
		ob_start();
		?>

		<div class="paying-attention-update-me">
			<pre style="display: none;">
				<?php echo wp_json_encode( $attributes ); ?>
			</pre>
		</div>
		<?php
		return ob_get_clean();
	}
}

$are_you_paying_attention = new  Are_You_Paying_Attention();
